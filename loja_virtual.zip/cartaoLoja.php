<?php
    session_start();
    require '../../app_loja_virtual_PRIVATE/cartaoLoja.php';

?>
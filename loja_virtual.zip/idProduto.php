<?php

    require '../../app_loja_virtual_PRIVATE/idProduto.php';

?>